#include<stdio.h>
#include<stdlib.h>

struct node
{
struct node *Left;
int info;
struct node *Right;
}*L=NULL,*R=NULL;

void insert(int);
void delete(int);
void display();

void main()
{
int cho,n,m;

do
{
	printf("\nMenu:\n1. Insertion \n2. Deletion \n3. Display \n4. Exit\nChoice: ");
	scanf("%d",&cho);

	switch(cho)
	{
		case 1: printf("\nEnter the element to insert: ");
			scanf("%d",&n);
			insert(n);
			printf("\nThe element is inserted succesfully:\n");
			break;

		case 2: printf("\nEnter the element to delete: ");
			scanf("%d",&n);
			delete(n);
			printf("\nThe element is deleted succesfully:\n");
			break;

		case 3: printf("\nThe linked list is:\n");
			display();
			break;

		case 4: printf("\n");
			break;

		default: printf("\nInvalid choice\n");
			 break;
	}
}while(cho!=4);
}

void insert(int x)
{
	int m;
	struct node *New,*save=L;
	
	New=(struct node *)malloc(sizeof(struct node));

	if(New==NULL)
	{
		printf("\noverflow");
		return;
	}
	
	New->info=x;
	
	if(R==NULL)
	{
		New->Right=NULL;
		New->Left=NULL;
		L=New;
		R=New;
		return;
	}
	
	printf("\nEnter the element before which to insert: ");
	scanf("%d",&m);

	if(L->info==m)
	{
		New->Left=NULL;
		New->Right=L;
		L->Left=New;
		L=New;
		return;
	}

	while(save->Right!=NULL && save->info!=m)
		save=save->Right;
	
	if(save->info!=m)
		printf("\nNode not found\n");

	else
	{
		New->Left=save->Left;
		New->Right=save;
		(save->Left)->Right=New;
		save->Left=New;
	}
}

//Deletion
void delete(int x)
{
	if(R==NULL)
	{
		printf("\nUnderflow\n");
		return;
	}

	if(L==R && L->info==x)
	{
		free(L);
		L=NULL;
		R=NULL;
	}
	else if(L->info==x)
	{
		L=L->Right;
		L->Left=NULL;
	}
	else if(R->info==x)
	{
		R=R->Left;
		R->Right=NULL;
	}
	else
	{
		struct node *save=L;

		while(save->Right!=NULL && save->info!=x)
			save=save->Right;

		if(save->info!=x)
			printf("\nNode not found\n");
		else
		{
			(save->Left)->Right=save->Right;
			(save->Right)->Left=save->Left;
		}
	}
}

//Displaying the Linked List
void display()
{
	struct node *temp=L;
	if(temp==NULL)
	printf("NULL");
	printf("\n");
	while(temp!=NULL)
	{
		printf("%d ",temp->info);
		temp=temp->Right;
	}
	
	
}
